﻿using CoinMarketCapApp.Models;
using NoobsMuc.Coinmarketcap.Client;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Input;

namespace CoinMarketCapApp.ViewModels
{
    public class CryptoMarketViewModel : INotifyPropertyChanged
    {
        public ICommand SortCommand { get; }
        public ICommand NextPageCommand { get; }
        public ICommand PreviousPageCommand { get; }

        private bool sortAscending = true;


        private ObservableCollection<CryptoCoin> coins;
        public ObservableCollection<CryptoCoin> Coins
        {
            get { return coins; }
            set
            {
                coins = value;
                OnPropertyChanged(nameof(Coins));
            }
        }

        //private ObservableCollection<CryptoCoin> pagedCoins;
        //public ObservableCollection<CryptoCoin> PagedCoins
        //{
        //    get { return pagedCoins; }
        //    set
        //    {
        //        pagedCoins = value;
        //        OnPropertyChanged(nameof(PagedCoins));
        //    }
        //}
        private Pagination<CryptoCoin> pagedCoins;
        public Pagination<CryptoCoin> PagedCoins
        {
            get { return pagedCoins; }
            set
            {
                pagedCoins = value;
                OnPropertyChanged(nameof(PagedCoins));
            }
        }
        private void LoadData()
        {
            ICoinmarketcapClient client = new CoinmarketcapClient("41947fa6-bfb7-487c-8815-f316cfd33db3");
 
            var currencyList = client.GetCurrencies();
            if (currencyList != null)
            {
                Coins = new ObservableCollection<CryptoCoin>();

                foreach (var cryptoData in currencyList)
                {
                    var coin = new CryptoCoin
                    {
                        Name = cryptoData.Name,
                        Price = cryptoData.Price,
                        Symbol = cryptoData.Symbol,
                        LaunchedDate = cryptoData.DateAdded // 此处假设API响应中有一个名为DateAdded的属性
                    };

                    Coins.Add(coin);
                }
            }

        }

        public CryptoMarketViewModel()
        {
            Coins = new ObservableCollection<CryptoCoin>();
            SortCommand = new RelayCommand(SortCoinsByColumn);
            NextPageCommand = new RelayCommand(NextPage);
            PreviousPageCommand = new RelayCommand(PreviousPage);
            LoadData();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        //public void SortCoinsByColumn(string sortBy)
        //{
        //    if (sortAscending)
        //    {
        //        Coins = new ObservableCollection<CryptoCoin>(Coins.OrderBy(c => c.GetType().GetProperty(sortBy).GetValue(c, null)));
        //    }
        //    else
        //    {
        //        Coins = new ObservableCollection<CryptoCoin>(Coins.OrderByDescending(c => c.GetType().GetProperty(sortBy).GetValue(c, null)));
        //    }

        //    sortAscending = !sortAscending;
        //}
        public void SortCoinsByColumn(object parameter)
        {
            string column = parameter as string;
            if (column != null)
            {
                if (sortAscending)
                {
                    Coins = new ObservableCollection<CryptoCoin>(Coins.OrderBy(c => c.GetType().GetProperty(column).GetValue(c, null)));
                }
                else
                {
                    Coins = new ObservableCollection<CryptoCoin>(Coins.OrderByDescending(c => c.GetType().GetProperty(column).GetValue(c, null)));
                }

                sortAscending = !sortAscending;
            }
        }
        //private void UpdatePagedCoins()
        //{
        //    // 在这里根据需要将Coins分页，并将结果设置给PagedCoins
        //    int pageSize = 10; // 每页显示的项数
        //    PagedCoins = new ObservableCollection<CryptoCoin>(Coins.Take(pageSize));
        //}

        private void UpdatePagedCoins()
        {
            int pageSize = 10; // 每页显示的项数
            int currentPage = 1; // 当前页数，可以根据需要进行调整

            var pagedData = Coins.Skip((currentPage - 1) * pageSize).Take(pageSize).ToList();

            PagedCoins = new Pagination<CryptoCoin>
            {
                Items = new ObservableCollection<CryptoCoin>(pagedData),
                CurrentPage = currentPage,
                TotalPages = (int)Math.Ceiling((double)Coins.Count / pageSize),
                PageSize = pageSize
            };
        }

        private void NextPage(object parameter)
        {
            PagedCoins.CurrentPage++;
            UpdatePagedCoins();
        }

        private void PreviousPage(object parameter)
        {
            PagedCoins.CurrentPage--;
            UpdatePagedCoins();
        }
    }
}
